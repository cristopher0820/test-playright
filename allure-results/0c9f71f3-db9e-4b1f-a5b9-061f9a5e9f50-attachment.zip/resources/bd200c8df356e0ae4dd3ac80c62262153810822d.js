pendo.guideContent('VZt3ape4CPU9r83LbMR5LMvIy0Y@GinxnXh-xXjl6QlBjfOsf61OmGI','1fDhVLEatv0WX9M0THgdWtBysMU',"<div id=\"integration-container-37e9d139-0130-45e3-90c9-be4386833c35\"></div><script id=\"pendo-inline-script\">\n<% if (typeof guide !== 'undefined') { %>\nvar guide = pendo.findGuideById('<%= guide.id %>');\nvar step = guide && guide.findStepById('<%= step.id %>');\n<% } %>\n/*BEGIN PENDO SCRIPT WRAPPER*/\n(function () {\n    var integrationContainer = document.getElementById('integration-container-37e9d139-0130-45e3-90c9-be4386833c35');\n    if(!integrationContainer) return;\n\n    var guideContainer = integrationContainer;\n    for(var i = 0; i < 10; i++) {\n        if(guideContainer.id === 'pendo-guide-container' || guideContainer.tagName.toLowerCase() === 'body') break;\n\n        guideContainer = guideContainer.parentElement;\n    }\n\n    if(guideContainer.id !== 'pendo-guide-container') return;\n\n    var resourceCenter = pendo.Sizzle('#pendo-resource-center-container');\n    var resourceCenterHeight = resourceCenter[0].offsetHeight;\n    var guideContainerHeight = guideContainer.offsetHeight;\n    var heightToFill = resourceCenterHeight - guideContainerHeight;\n    integrationContainer.style.height = '100%';\n\n    pendo.BuildingBlocks.BuildingBlockResourceCenter.launchIntegrationByNameAndProvider('helpcenter', 'zendesk', integrationContainer);\n})()\n/*END PENDO SCRIPT WRAPPER*/</script>",function(root) {
var __t, __p = '';
__p += '<div id="integration-container-37e9d139-0130-45e3-90c9-be4386833c35"></div>';
return __p
},function(step,guide){(function () {
    var integrationContainer = document.getElementById('integration-container-37e9d139-0130-45e3-90c9-be4386833c35');
    if(!integrationContainer) return;

    var guideContainer = integrationContainer;
    for(var i = 0; i < 10; i++) {
        if(guideContainer.id === 'pendo-guide-container' || guideContainer.tagName.toLowerCase() === 'body') break;

        guideContainer = guideContainer.parentElement;
    }

    if(guideContainer.id !== 'pendo-guide-container') return;

    var resourceCenter = pendo.Sizzle('#pendo-resource-center-container');
    var resourceCenterHeight = resourceCenter[0].offsetHeight;
    var guideContainerHeight = guideContainer.offsetHeight;
    var heightToFill = resourceCenterHeight - guideContainerHeight;
    integrationContainer.style.height = '100%';

    pendo.BuildingBlocks.BuildingBlockResourceCenter.launchIntegrationByNameAndProvider('helpcenter', 'zendesk', integrationContainer);
})()});