jQuery.fn.toggleFade = function(speed, easing, callback) {
	return this.animate({opacity: 'toggle'}, speed, easing, callback);
};
jQuery.toggleCookie = function(Cookie) {
	$.cookie(Cookie,$.cookie(Cookie) == 1 ? 0 : 1);
};
jQuery.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};
function toggleSetting(setting) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: {
			method: "ajaxToggleUserSetting",
			"name": setting
		}
	})
	.done(function(){})
	.fail(function(e) {
		alert(e.responseText);
		alert(e.statusText);
	});
}
function getProgramsByKeywords(keywords) {
	if(keywords.length > 3){
		$.ajax({
			type: "GET",
		dataType: 'json',
			url: "/AjaxProxy.cfc",
			data: { method: "ajaxGetProgramByKeywords", "Keywords": keywords }
		})
		.done(function( rs ) {
			popRS(rs);
		})
		.fail(function(e) {
			//alert(e.responseText);
			alert(e.statusText);
		});
	}
}
function cycleInit(id,progID,bCurrent,msgDiv,bActive,bReturnUnassigned) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "getAllProgramTerms", "Program_ID": progID, "bShowCurrent": bCurrent, "bShowActive": bActive, "bOnlyReturnUnassignedTermYears": bReturnUnassigned }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs,true);
		if(bCurrent){
			$('#cycleMsg').show();
			$('#cycleMsg2').hide();
		} else {
			$('#cycleMsg').hide();
			$('#cycleMsg2').show();
		}
	})
	.fail(function(e) {
		alert(e.responseText);
		alert(e.statusText);
	});
}
function responseInit(id,callingId,targetId,spID,selFirst) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetStudentParamUniqueResponses", "Student_Param_ID": spID }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs,selFirst);
		$('#'+targetId).show();
		$('#'+callingId).hide();
		$('#'+id+' option:eq(1)').css({'background-color':'#efefef'});
		try {
			eval('_cb_restoreSP'+spID+'()');
		} catch(e) {}
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function responseDefault(id,callingId,targetId,spID,selFirst) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetStudentParamAllOptionValues", "Student_Param_ID": spID }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs,selFirst);
		$('#'+targetId).show();
		$('#'+callingId).hide();
		$('#'+id+' option:eq(1)').css({'background-color':'#efefef'});
		try {
			eval('_cb_restoreSP'+spID+'()');
		} catch(e) {}
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function prgInit(id,bActive,excl) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetPrograms", "active": bActive }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs,0,excl);
	})
	.fail(function(e) {
		alert(e.responseText);
		alert(e.statusText);
	});
}
function prgGrpInit(id) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetProgramGroups" }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function sponsorInit(id) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetSponsors" }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function meta01Init(id) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetMETA01" }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function meta02Init(id) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetMETA02" }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function spInit(id,types) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetStudentParameters", "restrictToTypes": types }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function spValuesInit(id,sp,truncate,duallistbox) {
	if(typeof truncate === 'undefined'){
		truncate = false;
	}
	if(typeof duallistbox === 'undefined'){
		duallistbox = false;
	}
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetStudentParameterValues", "id": sp, "bTruncate": truncate }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
		if (duallistbox) {
			duallistbox.bootstrapDualListbox('refresh', true);
		};
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function paramValInit(id,val) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetProgramParameterValues", "Param_ID": val }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function fscInit(id,context,val) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetSchools", "vchcontext": context, "vchvalue": val }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function termInit(id,msgDiv,sStatus) {
	var tmpStatus = 'Current';
	if(sStatus != ''){
		tmpStatus = sStatus;
	}
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetApplicationCycleTerms", "Status": tmpStatus }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs);
		$('#'+msgDiv).hide();
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function procMapInit(id,msgDiv,sStatus) {
	var tmpStatus = 'Current';
	if(sStatus != ''){
		tmpStatus = sStatus;
	}
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetProcessMaps", "Status": tmpStatus }
	})
	.done(function( rs ) {
		populateSelectBox(id,rs,1);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function killObjPermission(iUserID,iObjectID,vchKeyID,objDiv,bRemoveAll){
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxRemoveObjectPermission", "iUserID": iUserID, "iObjectID": iObjectID, "vchKeyID": vchKeyID, "bRemoveAll": bRemoveAll }
	})
	.done(function( rs ) {
		if(bRemoveAll){
			$('#all-'+objDiv).remove();
			$('#rem-'+objDiv).remove();
		} else {
			$('#'+objDiv).remove();
			var tmp = objDiv.split('-')[0];
			if($.trim($('#all-'+tmp).html())=='') {
				$('#rem-'+tmp).remove();
			}
		}
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function killGroupObjPermission(iGroupID,iObjectID,vchKeyID,objDiv,bRemoveAll){
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxRemoveGroupObjectPermission", "iGroupID": iGroupID, "iObjectID": iObjectID, "vchKeyID": vchKeyID, "bRemoveAll": bRemoveAll }
	})
	.done(function( rs ) {
		if(bRemoveAll){
			$('#all-'+objDiv).remove();
			$('#rem-'+objDiv).remove();
		} else {
			$('#'+objDiv).remove();
			var tmp = objDiv.split('-')[0];
			if($.trim($('#all-'+tmp).html())=='') {
				$('#rem-'+tmp).remove();
			}
		}
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function parseCFJSON(json) {
   var result = [],
       data = json;
   try {
	   for (var j = 0; j < data.DATA.length; j++) {
	      result[j] = {};
	      for (var i = 0; i < data.COLUMNS.length; i++) {
	         result[j][data.COLUMNS[i].toLowerCase()] = data.DATA[j][i];
	      }
	   }
	   return result;
   } catch(e){
   	   return eval(json.DATA);
   }
}
function populateSelectBox(id,rs,bSelFirst,excl,bShowSelect,valuedelim) {
	RS = parseCFJSON(eval(rs));
	var frmElem = document.getElementById(id);
	var options = '';
	if(bShowSelect){
		options += '<option value="">- select -</option>';
	}
	var found = 0;
	if(valuedelim){
		var bValueDelim = true;
	} else {
		var bValueDelim = false;
	}
	if(RS.length > 0){
		for (var i = 0; i < RS.length; i++) {
			if((excl) && (excl.length)){
				found = 0;
				for(var j = 0; j < excl.length ; j++) {
					if(RS[i].id == excl[j].value){
						found = 1;
					}
				}
				if(found == 0){
					if(bValueDelim){
						options += '<option value="' + RS[i].id + valuedelim + '">' + RS[i].name + '</option>';
					} else {
						options += '<option value="' + RS[i].id + '">' + RS[i].name + '</option>';
					}
				}
			} else {
				if(bValueDelim){
					options += '<option value="' + RS[i].id + valuedelim + '">' + RS[i].name + '</option>';
				} else {
					options += '<option value="' + RS[i].id + '">' + RS[i].name + '</option>';
				}
			}
		}
		$("select#"+id).html(options);
		if(!bSelFirst){
			frmElem.selectedIndex = -1;
		} else {
			frmElem.selectedIndex = 0;
		}
		frmElem.disabled=false;
	} else {
		$("select#"+id).html('No records exit.');
	}
}
function selectItems(id,itemArray) {
	var frmElem = document.getElementById(id);
	for(i=0;i<frmElem.options.length;i++){
		optValue = frmElem.options[i].value;
		for(j=0;j<itemArray.length;j++){
			if(optValue === itemArray[j]){
				frmElem.options[i].selected = true;
			}
		}
	}
}
function ammapcont(continent,defaultCountryColor,labelBackgroundColor) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "GetAmapContinent", "vchContinent": continent }
	})
	.done(function( rs ) {
		var settings="<settings><area><balloon_text>{title}</balloon_text><color_unlisted>"+defaultCountryColor+"</color_unlisted></area><balloon><color>"+labelBackgroundColor+"</color></balloon></settings>";
		flashMovie.setSettings(settings);
		flashMovie.setData(rs['DATA']);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function setProgramPins(country) {
	alert(country);
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "GetAmapProgramPins", "vchCountry": country }
	})
	.done(function( rs ) {
		flashMovie.setData(rs['DATA']);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function getNote() {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "getNoteData" }
	})
	.done(function( rs ) {
		var htm = '';
		$('#notes-content').html('');
		rs = eval(rs);
		htm = '<table class="table table-condensed table-striped data-table">';
		for(i=0;i<rs.length;i++){
			htm +=  '<tr><th colspan="2">'+rs[i]['NOTE_DATE']+'</th></tr>';
			htm += '<tr><td>'+rs[i]['TEXT']+'</td><td class="compact-column"><a href="javascript:void(0);" onclick="deleteNote('+rs[i]['NOTEID']+');"><i class="fa fa-close fa-lg"><span class="sr-only">Delete</span></i><span class="sr-only">Delete</span></a></td></tr>';
		}
		htm += '</table>';
		$('#notes-content').html(htm);
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function addNote(cont,noteDate) {
	$.ajax({
		type: "POST",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "addNotes", "cont": cont, "noteDate": noteDate }
	})
	.done(function() {
		getNote();
		$('#newNotes').val('');
		$('#txtRemLen1').html('2000');
		$('#newNote').modal('hide');
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function getDeadlinePanel(Program_ID) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "getpgmDeadlines", "Program_ID": Program_ID }
	})
	.done(function(rs) {
		document.getElementById('PopupPanel').innerHTML=rs;
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function informAboutActivation() {
	alert('The Terra Dotta Location Web Service is currently inactive. Please contact a faculty member for more information.');
}
function getLocation(program_city) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "getLocatn", "program_city": program_city }
	})
	.done(function(rs) {
		var selSelected = document.getElementById('selSelected');
		rs = eval(rs);
		if(rs == 999) {
			informAboutActivation();
		} else {
			document.getElementById('selAvailable').length = 0;
			if(rs.length>0){
				var cnt = 0;
				for(i=0;i<rs.length;i++){ /*qryTDCLContent.asciiname = replaceList(qryTDCLContent.asciiname,chr(8216) & ", " & chr(8217) & ", " & chr(8220) & ", " & chr(8221) & ", " & chr(8212) & ", " & chr(8213) & ", " & chr(8230), "',', "", "",--,--,..."); */
					if(rs[i]['COUNTRY'] != '')
						var info=rs[i]['TEXT']+','+' '+rs[i]['COUNTRY']+' ('+rs[i]['REGION']+')';
					else
						var info=rs[i]['TEXT'];
					var latLong=rs[i]['LATITUDE']+'/'+rs[i]['LONGITUDE'];
					var bExists = false;
					for(j=0;j<selSelected.options.length;j++){
						if(selSelected.options[j].text == info){
							var bExists = true;
						}
					}
					if(bExists == false){
						document.getElementById('selAvailable').options[cnt] = new Option(info,latLong);
						cnt++;
					}
				}
				if(cnt==0){
					alert('All available results have already been selected.');
				}
			} else {
				alert('The Terra Dotta Location Web Service did not find a match for this location. You may choose to modify the name and search again.');
			}
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function getLatitude(program_city,program_country,optionValue,latitude,longitude) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "getLocatn", "program_city": program_city, "optionValue": optionValue, "program_country": program_country }
	})
	.done(function(rs) {
		rs = eval(rs);
		if(rs == 999) {
			informAboutActivation();
		} else {
			if(rs.length == 0) {
				alert("This location could not be found in the TDLWS");
			} else if (rs.length == 1) {
			var info1,info2,i,admincode,geonameid,elevation,timezone,population,region;
			var n="NULL";var p=0;
			region=rs[0]['REGION'];
			if(!rs[0]['ADMINCODE']){ admincode=n}else{ admincode=rs[0]['ADMINCODE']}
			if(!rs[0]['GEONAMEID']){ geonameid=p;}else{ geonameid=rs[0]['GEONAMEID'];}
			if(!rs[0]['ELEVATION']){ elevation=n;}else{ elevation=rs[0]['ELEVATION'];}
			if(!rs[0]['TIMEZONE']){ timezone=n;}else{ timezone=rs[0]['TIMEZONE'];}
			if(!rs[0]['POPULATION']){ population=p;}else{ population=rs[0]['POPULATION'];}

			setLangorLat(rs[0]['LONGITUDE'],rs[0]['LATITUDE'],admincode,geonameid,elevation,timezone,population,region);

			} else {
					prepareForMultyCities(rs);
			}
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	})
	.complete(function(){
		$.fancybox.hideLoading();
	});
}
function fetchInfo(program_city,optionValue,listCount) {
	$.ajax({
		type: "POST",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "getLocatn", "program_city": program_city, "optionValue": optionValue }
	})
	.done(function(rs) {
		rs = eval(rs);
		if(rs == 999) {
			informAboutActivation();
		} else if (rs["error"]){
			alert('an error occurred.');
		} else {
			preparetable(rs);
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	})
	.complete(function(){
		$.fancybox.hideLoading();
	});
}
function deleteNotes(noteid) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "deleteNotes", "noteid": noteid }
	})
	.done(function(rs) {
		getNote();
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function allowedToSavePgm(Program_ID,Program_Name) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "SavePgm", "Program_ID": Program_ID },
		headers: { "X-TDCF-XSRF-PROTECTION": true }
	})
	.done(function(rs) {
		document.getElementById('pgmallowed').value=rs;
		var pgmcheck=document.getElementById('pgmallowed').value;
		if (pgmcheck!=''){
			if($('.pgm_'+Program_ID)) {
				$('.pgm_'+Program_ID).removeAttr('disabled');
				alert(pgmcheck);
			}
		} else {
			SavePgm(Program_ID,Program_Name);
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function SavePgm(Program_ID,Program_Name) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "SaveThisPgm", "Program_ID":Program_ID, "Program_Name":Program_Name },
		headers: { "X-TDCF-XSRF-PROTECTION": true }
	})
	.done(function(rs) {
		if($('.pgm_'+Program_ID))
			$('.pgm_'+Program_ID).removeAttr('disabled');
		alert(rs);
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function getDataSetValue(idatasetid,selectbox,keywords,valuedelim) {
	if(keywords.length >= 2) {
		$.ajax({
			type: "GET",
			dataType: 'json',
			url: "/AjaxProxy.cfc",
			data: { method: "ajaxGetDataSetValues", "dataset": idatasetid, "keywords": keywords }
		})
		.done(function(rs) {
			if(rs == 999) {
				informAboutActivation();
			} else {
				var RS = parseCFJSON(eval(rs));
				if( RS.length && ( RS[0].id.substring( 0, keywords.length ) == keywords || RS[0].name.substring( 0, keywords.length ) == keywords ) ){
					populateSelectBox(selectbox,rs,1,'',false,valuedelim);
				} else {
					populateSelectBox(selectbox,rs,0,'',false,valuedelim);
				}
			}
		})
		.fail(function(e) {
			alert(e.statusText);
		});
	}
}
function getIATALocationCodes(id,keywords) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetIATALocationCodes", "keywords": keywords }
	})
	.done(function(rs) {
		if(rs == 999) {
			informAboutActivation();
		} else {
			populateSelectBox(id,rs,0);
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function getIATALocationFromCode(id,loc) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetIATALocationFromCode", "loc": loc }
	})
	.done(function(rs) {
		if(rs == 999) {
			informAboutActivation();
		} else {
			populateSelectBox(id,rs,true);
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function getCarrierCodes(id,keywords) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetCarrierCodes", "keywords": keywords }
	})
	.done(function(rs) {
		if(rs == 999) {
			informAboutActivation();
		} else {
			populateSelectBox(id,rs,0);
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function getCarrierFromCode(id,carcode) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetCarrierFromCode", "carcode": carcode }
	})
	.done(function(rs) {
		if(rs == 999) {
			informAboutActivation();
		} else {
			populateSelectBox(id,rs,true);
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function setAddressCoordinates(id,uid,lat,lon,hash,fa) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxSetAddressCoordinates", "id":id, "uid":uid, "lat":lat, "lon":lon, "hash":hash }
	})
	.done(function(uid) {
		if(fa!=''){
			location.href=fa;
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}
function geocodeResponseHandler(statusObj) {
	if(statusObj=='ZERO_RESULTS'){
		return 'One or more addresses was not found. Please check the address and try again.';
	} else if (statusObj=='OVER_QUERY_LIMIT') {
		return 'Google Geocoding API: The Maximum number of requests has been reached. Please contact support.';
	} else if (statusObj=='REQUEST_DENIED') {
		return 'Google Geocoding API: The request has been denied. Please contact support.';
	} else if (statusObj=='INVALID_REQUEST') {
		return 'Google Geocoding API: The request is invalid.';
	} else if (statusObj!='') {
		return 'Google Geocoding API: An unhandled response was received. Please contact support with the following information: ' + statusObj.toString() ;
	}
}
function getCitiesInCountry(id,City) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetCitiesInCountry", "program_city": City }
	})
	.done(function(rs) {
		populateSelectBox(id,rs,true);
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}

function addOption(selectbox,text,value){
	var optn = document.createElement("option");
	optn.text = text;
	optn.value = value;
	selectbox.options.add(optn);
}
function addSelOption(selectbox,text,value){
	var optn = document.createElement("option");
	optn.text = text;
	optn.value = value;
	optn.selected = 'selected';
	selectbox.options.add(optn);
}
function removeAllOptions(selectbox){
	var i;
	for(i=selectbox.options.length-1;i>=0;i--){
		selectbox.remove(i);
	}
}
function createHTMLNode(htmlCode) {
	var htmlNode = document.createElement('span');
	htmlNode.innerHTML = htmlCode;
	return htmlNode;
}
function myToggle(divId, divId2) {
	if($('#arr1').hasClass('fa-arrow-right')){
		$('#arr1').removeClass('fa-arrow-right');
		$('#arr1').addClass('fa-arrow-down');
	}else{
		$('#arr1').removeClass('fa-arrow-down');
		$('#arr1').addClass('fa-arrow-right');
	}
	myToggle2(divId2);
}
function getElementReference(elementId)	{
	var value=false;
	if(document.ids) {
		value=document.ids[elementId];
	}
	else if (document.layers) {
		value=document.layers[elementId];
	} else {
		if(document.all) {
			value=document.all[elementId];
		} else if(document.getElementById) {
			value=document.getElementById(elementId);
		}
	}
	return value;
}
function getStyleReference(elementId) {
	var value=false;
	if(getElementReference(elementId)) {
		value=getElementReference(elementId);
		if(!document.layers) {
				value=value.style;
		}
	}
	return value;
}
function myToggle2(divId){
	if((divId.substring(0,7))=='Crstrow'){
		var dis = ("none" == getStyleReference(divId).display ? "table-row" : "none");
	}else{
		var dis = ("none" == getStyleReference(divId).display ? "block" : "none");
	}
	getStyleReference(divId).display = dis;
}
function myInlineToggle(divId){
	var dis = ("none" == getStyleReference(divId).display ? "inline" : "none");
	getStyleReference(divId).display = dis;
}
/* Custom TOC script */
function HoverClasses(id){
	if (document.getElementById){
		var tr = document.getElementById('TR'+id);
		var bl = document.getElementById('TRBullet'+id);
		var tx = document.getElementById('TRText'+id);
		var subGrp = document.getElementById('SubGroup'+id);

		if(tr){
			if(subGrp){
				if(subGrp.style.display == "none"){
					tr.className = ('TRClass' == tr.className ? 'TRClassHover' : 'TRClass');
				}
			} else {
				tr.className = ('TRClass' == tr.className ? 'TRClassHover' : 'TRClass');
			}
		}
		if(bl){
			if(subGrp){
				if(subGrp.style.display == "none"){
					bl.className = 'TRBullet';
				}
			} else {
				if(bl.className != ''){
					bl.className = 'TRBullet';
				}
			}
		}
		if(tx){
			tx.className = ('TRText' == tx.className ? 'TRTextHover' : 'TRText');
		}
	}
}
function ClickClass(num){
	var elem = document.getElementById('TRBullet'+num);
	if (document.getElementById){
		if(elem){
			elem.className = ('TRBulletOn' == elem.className ? 'TRBullet' : 'TRBulletOn');
		}
	}
}
function WM_toggle(id) {
	if (document.getElementById){
		var subGroupToOpen = document.getElementById('SubGroup'+id);
		if(subGroupToOpen){
			subGroupToOpen.style.display = ('none' == subGroupToOpen.style.display ? 'block' : 'none');
		}
	}
}
function WM_initialize(subCls,lnkCls){
	if (document.getElementById){
		var toExpand = document.getElementById('SubGroup'+subCls); // Element to expand
		var toHilightTR = document.getElementById('TR'+subCls); // Hilights the expanded row
		var toHilightTRText = document.getElementById('TRText'+subCls); // Hilights the expanded row
		var toToggleBL = document.getElementById('TRBullet'+subCls); // Toggles the expanded bullet
		var toHilightTD = document.getElementById('TD'+subCls+'-'+lnkCls); // Hilights the chosen link
		if(toExpand) {
			toExpand.style.display = 'block';
			if(toToggleBL){
				if(toToggleBL.display != "none"){
					ClickClass('TRBullet'+subCls);
				}
			}
		}
		if(toHilightTR) {
			toHilightTR.className = 'TRClassOn';
			toHilightTR.onmouseover = function(){void(0)}
			toHilightTR.onmouseout = function(){void(0)}
		}
		if(toHilightTRText) {
			toHilightTRText.className = 'TRTextOn';
			toHilightTRText.onmouseover = function(){void(0)}
			toHilightTRText.onmouseout = function(){void(0)}
		}
		if(toHilightTD) {
			toHilightTD.className = 'TDTextOn';
			toHilightTD.onmouseover = function(){void(0)}
			toHilightTD.onmouseout = function(){void(0)}
		}
		if(toToggleBL){
			if(toExpand){
				toToggleBL.className = 'TRBulletOn';
			}
		}
	}
}
function profileSMSTest(smsNumber, carrier_ID,carrierSuffix,targetURL){

	var features = 'status=yes,scrollbars=yes,width=500,height=250,resizable=yes,screenX=200,screenY=100,left=200,top=100';
	if(targetURL == ""){
		targetURL = "index.cfm?FuseAction=Students.TestProfileSMS";
	}
	if (carrierSuffix !== ""){
	 var page = targetURL + "&SMS_Number=" + smsNumber + "&Carrier_ID=0&Carrier_Suffix=" + carrierSuffix;
	}
	else{
	var page = targetURL + "&SMS_Number=" + smsNumber + "&Carrier_ID=" + carrier_ID;
	}
	if(navigator.appName !='Microsoft Internet Explorer'){
		popup(page, 'Mobile Phone Text Messaging (SMS): Test ', features);
	}
	else{
		popup(page, '_blank', features);
	}

}

function openGlossary(ID, Type){
	var features = 'status=yes,scrollbars=yes,width=500,height=250,resizable=yes,screenX=200,screenY=100,left=200,top=100';
	var page = "index.cfm?FuseAction=Public.Glossary&Type=" + Type + "&ID=" + ID;
	popup(page, 'Glossary', features);
}
function popup(sURL,sTitle,sFeatures) {
	var winWidth = (screen.width - 100);
	var winHeight = (screen.height - 200);
	if (sFeatures == ''){
		winprops = 'height=' + winHeight + ',width=' + winWidth + ",top=100,left=50,location=no,menubar=no,resizable=yes,status=no,titlebar=no,statusbar=-1,toolbar=no,scrollbars=yes";
	} else {
		winprops = sFeatures;
	}
	window.open(sURL, sTitle, winprops);
}
function disableEnterKey(e) {
	var key;
	if(window.event) {
		key = window.event.keyCode;	 //IE
	} else {
		key = e.which;	 //firefox
	}
	if(key == 13) {
		return false;
	} else {
		return true;
	}
}
function getQueryVariable(variable) {
	var query = window.location.search.substring(1);
	var vars = query.split("&");
	 for (var i=0;i<vars.length;i++)
	 {
	 	var pair = vars[i].split("=");
	 	if (pair[0] == variable)
	 	{
	 		return pair[1];
	 	}
	 }
}
function qstInit(id,bActive,excl) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxGetQuestionnaires" }
	})
	.done(function( rs ) {
		populateSelectBoxGrouped(id,rs,0,excl);
	})
	.fail(function(e) {
		alert(e.responseText);
		alert(e.statusText);
	});
}
function populateSelectBoxGrouped(id,rs,bSelFirst,excl) {
	RS = rs;
	var frmElem = document.getElementById(id);
	var options = '';
	var found = 0;
	if(RS.length > 0){
		for (var i = 0; i < RS.length; i++) {
			options += '<optgroup label="' + RS[i].GROUP + '">';
			for (var k = 0; k < RS[i].DATA.IDS.length; k++) {
				tmp_id = RS[i].DATA.IDS[k];
				tmp_name = RS[i].DATA.NAMES[k];
				if((excl) && (excl.length)){
					found = 0;
					for(var j = 0; j < excl.length ; j++) {
						if(tmp_id == excl[j].value){
							found = 1;
						}
					}
					if(found == 0){
						options += '<option value="' + tmp_id + '">' + tmp_name + '</option>';
					}
				} else {
					options += '<option value="' + tmp_id + '">' + tmp_name + '</option>';
				}
			}
			options += '</optgroup>';
		}
		$("select#"+id).html(options);
		if(!bSelFirst){
			frmElem.selectedIndex = -1;
		} else {
			frmElem.selectedIndex = 0;
		}
		frmElem.disabled=false;
	} else {
		$("select#"+id).html('No records exit.');
	}
}
function groupDAOInsert(grp,obj,key,val,_cb) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxInsertGroupObject", "iGroupID": grp, "iObjectID": obj, "vchKeyID": key, "vchKeyID2": val }
	})
	.done(function() {
		//
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}
function userDAOInsert(usr,obj,key,val,_cb) {
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: { method: "ajaxInsertUserObject", "iUserId": usr, "iObjectID": obj, "vchKeyID": key, "vchKeyID2": val }
	})
	.done(function() {
		//
	})
	.fail(function(e) {
		//alert(e.responseText);
		alert(e.statusText);
	});
}

function prepareForMultyCities(rs) {

	var rows = "";
	var n="NULL";var p=0;
	var info1,info2,i,admincode,geonameid,elevation,timezone,population;
	for(i=0;i<rs.length;i++){
			region="'"+rs[i]['REGION'].replace(/'/g, "\\'")+"'";
			if(!rs[i]['ADMINCODE']){ admincode="'"+n+"'";}else{ admincode="'"+rs[i]['ADMINCODE'].replace(/'/g, "\\'")+"'";}
			if(!rs[i]['GEONAMEID']){ geonameid="'"+n+"'";}else{ geonameid="'"+rs[i]['GEONAMEID']+"'";}
			if(!rs[i]['ELEVATION']){ elevation="'"+n+"'";}else{ elevation="'"+rs[i]['ELEVATION']+"'";}
			if(!rs[i]['TIMEZONE']){ timezone="'"+n+"'";}else{ timezone="'"+rs[i]['TIMEZONE']+"'";}
			if(!rs[i]['POPULATION']){ population="'"+p+"'";}else{ population="'"+rs[i]['POPULATION']+"'";}

		info1 = rs[i]['TEXT'] + ',' + rs[i]['COUNTRY'] + '<br/>' + '(' + rs[i]['REGION'] + ')' + '<br/>' + rs[i]['ADMINCODE'] ;
		info2 = 'Lat/Long:' + rs[i]['LATITUDE'] + '/' + rs[i]['LONGITUDE'] + '<br/>' +'alternate name:' + rs[i]['ALTERNATENAMES'];
		rows += '<tr><td class="compact-column">' + info1 +'</td><td>' + info2 +'</td><td class="compact-column text-center"><input class="btn btn-primary" type="submit" value="Select" onclick="setLangorLat('+rs[i]['LONGITUDE']+','+rs[i]['LATITUDE']+','+admincode+','+geonameid+','+elevation+','+timezone+','+population+','+region+')"></td></tr>';
		}

	/* add dynamic multi city details */
	$("#multycity tr:gt(0)").remove();
	$("#multycity tr:first").after(rows);
	$.fancybox.hideLoading();

	/* show content in fancybox */
	$.fancybox({
        href : '#popupPanel',
        type : 'inline',
        content : $("#popupPanel"),
        title : 'Multiple Cities in Country found with this name'
    });
}

function preparetable(rs) {

	var rows = "";
	var rows1 = "";
	var cityindex = new Array();
	var id = "";
	var n="NULL";
	var p=0;
	var admincode,geonameid,elevation,timezone,population;
	if(rs.length>0){
		for(var i=0;i<rs.length;i++) {
			if(id != rs[i]['CITYID']){
				cityindex.push(i);
				countmultycity = countmultycity + 1;
			}
			id = rs[i]['CITYID'];
		}

		for(var i=0;i<rs.length;i++) {

		    var maindivid,subdivid;
		    var cityname ="'"+rs[i]['CITYNAME']+"'";
		    var countryname ="'"+rs[i]['COUNTRY']+"'";
		    var region ="'"+rs[i]['REGION']+"'";

		    if(!rs[i]['ADMINCODE']){ admincode="'"+n+"'";}else{ admincode="'"+rs[i]['ADMINCODE']+"'";}
			if(!rs[i]['GEONAMEID']){ geonameid="'"+p+"'";}else{ geonameid="'"+rs[i]['GEONAMEID']+"'";}
			if(!rs[i]['ELEVATION']){ elevation="'"+n+"'";}else{ elevation="'"+rs[i]['ELEVATION']+"'";}
			if(!rs[i]['TIMEZONE']){ timezone="'"+n+"'";}else{ timezone="'"+rs[i]['TIMEZONE']+"'";}
			if(!rs[i]['POPULATION']){ population="'"+p+"'";}else{ population="'"+rs[i]['POPULATION']+"'";}

			var k = rs[i]['CITYNAME']+','+rs[i]['COUNTRY']+'<br/>' + '('+rs[i]['REGION']+')'+'<br/>' + rs[i]['ADMINCODE'] ;
			var l = 'Lat/Long:'+rs[i]['LATITUDE']+'/'+rs[i]['LONGITUDE']+'<br/>'+'alternate name:'+rs[i]['ALTERNATENAMES'];

			var found = jQuery.inArray(i, cityindex);
			if (found >= 0){
				maindivid="'arr"+i+"'";
				subdivid="'pg"+i+"'";
				rows+='</table></div></div></div>';
				rows+='<div class="panel panel-primary"><div id='+maindivid+' class="table-responsive"><table class="table table-striped table-bordered table-data" ><tr onclick="myToggle('+maindivid+','+subdivid+')"><td class="bg-primary" ><div id="cityname"><i class="fa fa-arrow-right CursorPointer" id="arr1"   ></i>&nbsp;'+rs[i]['CITYNAME']+','+rs[i]['COUNTRY']+'('+rs[i]['REGION']+')'+'</div></td> </tr></table>';
				rows+='<div id='+subdivid+'  style="display: none; class="table-responsive""><table class="table table-striped table-bordered table-data"  ><tr><th class="compact-column" >Location</th><th>Additional Info</th><th class="compact-column">Action</th></tr>';
			}
			rows +='<tr><td>'+k+'</td><td>'+l+'</td><td><button type="submit" class="btn btn-primary" onclick="updatecity('+rs[i]['LONGITUDE']+','+rs[i]['LATITUDE']+','+cityname+','+countryname+','+region+','+maindivid+','+admincode+','+geonameid+','+elevation+','+timezone+','+population+','+region+')">Select</button></td></tr>';
		}
		$.fancybox.hideLoading();

		/* show content in fancybox */
		$.fancybox({
	        href : '#popupPanel',
	        type : 'inline',
	        content : rows,
	        title : 'Multiple city/country combinations were found for some locations',
	        minWidth:900,
	        minHeight:400,
	        width:$(window).width()-100,
	        'height':$(window).height()-100,
	        afterClose : function(){location.reload();   }

	    });

	}
	else{
		alert("No Locations Found with multiple entries");
		location.reload();
	}
}

function updatecity(longitude,latitude,city,country,region,divid,admincode,geonameid,elevation,timezone,population) {
	var removedivid;

	$.ajax({
		type: "POST",
		url: "/AjaxProxy.cfc",
		data: { method: "updateCityDetails", "City":city , "Country":country , "Region":region , "Latitude":latitude ,"Longitude":longitude,"Geonameid":geonameid,"Population":population,"Elevation":elevation,"Timezone":timezone,"Admin1code":admincode}
	})
	.done(function() {
		alert('Location updated  successfully');
		removedivid = document.getElementById(divid);
		removedivid.remove();
		countmultycity = countmultycity - 1;
		if(countmultycity==0){
			$.fancybox.close();
		}
	})
	.fail(function(e) {
		alert(e.statusText);
	});
}

function SearchApps(args,id) {
	var fullArgs = args + "&method=ajaxSearch";
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: fullArgs
	})
	.done(function(rs) {
		populateSelectBox(id,rs,0);
	})
	.fail(function(e) {
		alert(e.responseText);
		alert(e.statusText);
	});
}

function SearchProfiles(args,id) {
	var fullArgs = args + "&method=ajaxSearchProfiles";
	$.ajax({
		type: "GET",
		dataType: 'json',
		url: "/AjaxProxy.cfc",
		data: fullArgs
	})
	.done(function(rs) {
		populateSelectBox(id,rs,0);
	})
	.fail(function(e) {
		alert(e.responseText);
		alert(e.statusText);
	});
}

function toggleTips() {
	if( isLocalStorageAvailable() === true ){
		toggleTipsLocalStorage();
	} else {
		toggleTipsCookie();
	}
}

function toggleTipsCookie() {
	var cookiecheck = getCookie('TIPS');
	toggleSetting('_bUserShowTips'); // KR 3/16/2016: Added per Dain's advice for TDS16-20
	if (cookiecheck == 0) {
		document.cookie = "TIPS=1";
		document.getElementById('page-tips').style.display='block';
	} else if (cookiecheck == 1) {
		document.cookie = "TIPS=0";
		document.getElementById('page-tips').style.display='none';
	}
}

// <!--- from http://www.w3schools.com/js/js_cookies.asp --->
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
    }
    return "";
}

function toggleTipsLocalStorage() {
	var key = 'tds-tips-enabled';
	var state = localStorage.getItem( key );

	toggleSetting( '_bUserShowTips' );

	if( state == '0' ){
		localStorage.setItem( key, 1 );
		document.getElementById('page-tips').style.display='block';
	} else {
		document.getElementById('page-tips').style.display='none';
		localStorage.setItem( key, 0 );
	}
}

function isLocalStorageAvailable() {
    var tds = 'tds';
    try {
        localStorage.setItem(tds, tds);
        localStorage.removeItem(tds);
        return true;
    } catch(e) {
        return false;
    }
}